import inspect
import colorama


for method in dir(colorama):
    print(method)



# import inspect
# import colorama
# print(inspect.getmodule(colorama.get))
# print(inspect.getmodule(list))


# def getmodule(object, _filename=None):
#     """Return the module an object was defined in, or None if not found."""
#     if ismodule(object):
#         return object
#     if hasattr(object, '__module__'):
#         return sys.modules.get(object.__module__)
#     # Try the filename to modulename cache
#     if _filename is not None and _filename in modulesbyfile:
#         return sys.modules.get(modulesbyfile[_filename])
#     # Try the cache again with the absolute file name
#     try:
#         file = getabsfile(object, _filename)
#     except TypeError:
#         return None
#     if file in modulesbyfile:
#         return sys.modules.get(modulesbyfile[file])
#     # Update the filename to module name cache and check yet again
#     # Copy sys.modules in order to cope with changes while iterating
#     for modname, module in sys.modules.copy().items():
#         if ismodule(module) and hasattr(module, '__file__'):
#             f = module.__file__
#             if f == _filesbymodname.get(modname, None):
#                 # Have already mapped this module, so skip it
#                 continue
#             _filesbymodname[modname] = f
#             f = getabsfile(module)
#             # Always map to the name the module knows itself by
#             modulesbyfile[f] = modulesbyfile[
#                 os.path.realpath(f)] = module.__name__
#     if file in modulesbyfile:
#         return sys.modules.get(modulesbyfile[file])
#     # Check the main module
#     main = sys.modules['__main__']
#     if not hasattr(object, '__name__'):
#         return None
#     if hasattr(main, object.__name__):
#         mainobject = getattr(main, object.__name__)
#         if mainobject is object:
#             return main
#     # Check builtins
#     builtin = sys.modules['builtins']
#     if hasattr(builtin, object.__name__):
#         builtinobject = getattr(builtin, object.__name__)
#         if builtinobject is object:
#             return builtin